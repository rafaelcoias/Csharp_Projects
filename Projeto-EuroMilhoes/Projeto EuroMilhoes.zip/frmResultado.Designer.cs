﻿namespace Projeto_EuroMilhoes
{
    partial class frmResultado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEstrelas = new System.Windows.Forms.Label();
            this.lblNumeros = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.lblN3 = new System.Windows.Forms.Label();
            this.lblN4 = new System.Windows.Forms.Label();
            this.lblN5 = new System.Windows.Forms.Label();
            this.lblE2 = new System.Windows.Forms.Label();
            this.lblE1 = new System.Windows.Forms.Label();
            this.btnOrdenar = new System.Windows.Forms.Button();
            this.btnN1 = new System.Windows.Forms.Button();
            this.btnN2 = new System.Windows.Forms.Button();
            this.btnN3 = new System.Windows.Forms.Button();
            this.btnN4 = new System.Windows.Forms.Button();
            this.btnN5 = new System.Windows.Forms.Button();
            this.btnE2 = new System.Windows.Forms.Button();
            this.btnE1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblEstrelas
            // 
            this.lblEstrelas.AutoSize = true;
            this.lblEstrelas.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstrelas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblEstrelas.Location = new System.Drawing.Point(365, 27);
            this.lblEstrelas.Name = "lblEstrelas";
            this.lblEstrelas.Size = new System.Drawing.Size(134, 14);
            this.lblEstrelas.TabIndex = 8;
            this.lblEstrelas.Text = "Suas Estrelas :   00 00";
            this.lblEstrelas.Visible = false;
            // 
            // lblNumeros
            // 
            this.lblNumeros.AutoSize = true;
            this.lblNumeros.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeros.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblNumeros.Location = new System.Drawing.Point(365, 9);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(187, 14);
            this.lblNumeros.TabIndex = 7;
            this.lblNumeros.Text = "Seus Números :  00 00 00 00 00";
            this.lblNumeros.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Perpetua", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 36);
            this.label1.TabIndex = 9;
            this.label1.Text = "Números da Sorte";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Perpetua", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(12, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 36);
            this.label2.TabIndex = 10;
            this.label2.Text = "Estrelas";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btnVoltar
            // 
            this.btnVoltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltar.Location = new System.Drawing.Point(457, 197);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(86, 33);
            this.btnVoltar.TabIndex = 11;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = true;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblN1.Location = new System.Drawing.Point(30, 65);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(29, 20);
            this.lblN1.TabIndex = 12;
            this.lblN1.Text = "00";
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblN2.Location = new System.Drawing.Point(85, 65);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(29, 20);
            this.lblN2.TabIndex = 13;
            this.lblN2.Text = "00";
            this.lblN2.Visible = false;
            // 
            // lblN3
            // 
            this.lblN3.AutoSize = true;
            this.lblN3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblN3.Location = new System.Drawing.Point(144, 65);
            this.lblN3.Name = "lblN3";
            this.lblN3.Size = new System.Drawing.Size(29, 20);
            this.lblN3.TabIndex = 14;
            this.lblN3.Text = "00";
            this.lblN3.Visible = false;
            // 
            // lblN4
            // 
            this.lblN4.AutoSize = true;
            this.lblN4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblN4.Location = new System.Drawing.Point(204, 65);
            this.lblN4.Name = "lblN4";
            this.lblN4.Size = new System.Drawing.Size(29, 20);
            this.lblN4.TabIndex = 15;
            this.lblN4.Text = "00";
            this.lblN4.Visible = false;
            // 
            // lblN5
            // 
            this.lblN5.AutoSize = true;
            this.lblN5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblN5.Location = new System.Drawing.Point(262, 65);
            this.lblN5.Name = "lblN5";
            this.lblN5.Size = new System.Drawing.Size(29, 20);
            this.lblN5.TabIndex = 16;
            this.lblN5.Text = "00";
            this.lblN5.Visible = false;
            // 
            // lblE2
            // 
            this.lblE2.AutoSize = true;
            this.lblE2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblE2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblE2.Location = new System.Drawing.Point(85, 179);
            this.lblE2.Name = "lblE2";
            this.lblE2.Size = new System.Drawing.Size(29, 20);
            this.lblE2.TabIndex = 18;
            this.lblE2.Text = "00";
            this.lblE2.Visible = false;
            // 
            // lblE1
            // 
            this.lblE1.AutoSize = true;
            this.lblE1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblE1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblE1.Location = new System.Drawing.Point(30, 179);
            this.lblE1.Name = "lblE1";
            this.lblE1.Size = new System.Drawing.Size(29, 20);
            this.lblE1.TabIndex = 17;
            this.lblE1.Text = "00";
            this.lblE1.Visible = false;
            // 
            // btnOrdenar
            // 
            this.btnOrdenar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrdenar.Location = new System.Drawing.Point(1, 218);
            this.btnOrdenar.Name = "btnOrdenar";
            this.btnOrdenar.Size = new System.Drawing.Size(86, 23);
            this.btnOrdenar.TabIndex = 19;
            this.btnOrdenar.Text = "ordenar";
            this.btnOrdenar.UseVisualStyleBackColor = true;
            this.btnOrdenar.Visible = false;
            this.btnOrdenar.Click += new System.EventHandler(this.btnOrdenar_Click);
            // 
            // btnN1
            // 
            this.btnN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnN1.Location = new System.Drawing.Point(18, 65);
            this.btnN1.Name = "btnN1";
            this.btnN1.Size = new System.Drawing.Size(50, 23);
            this.btnN1.TabIndex = 20;
            this.btnN1.Text = "N. 1";
            this.btnN1.UseVisualStyleBackColor = true;
            this.btnN1.Click += new System.EventHandler(this.btnN1_Click);
            // 
            // btnN2
            // 
            this.btnN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnN2.Location = new System.Drawing.Point(78, 65);
            this.btnN2.Name = "btnN2";
            this.btnN2.Size = new System.Drawing.Size(50, 23);
            this.btnN2.TabIndex = 21;
            this.btnN2.Text = "N. 2";
            this.btnN2.UseVisualStyleBackColor = true;
            this.btnN2.Visible = false;
            this.btnN2.Click += new System.EventHandler(this.btnN2_Click);
            // 
            // btnN3
            // 
            this.btnN3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN3.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnN3.Location = new System.Drawing.Point(134, 65);
            this.btnN3.Name = "btnN3";
            this.btnN3.Size = new System.Drawing.Size(50, 23);
            this.btnN3.TabIndex = 22;
            this.btnN3.Text = "N. 3";
            this.btnN3.UseVisualStyleBackColor = true;
            this.btnN3.Visible = false;
            this.btnN3.Click += new System.EventHandler(this.btnN3_Click);
            // 
            // btnN4
            // 
            this.btnN4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN4.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnN4.Location = new System.Drawing.Point(190, 65);
            this.btnN4.Name = "btnN4";
            this.btnN4.Size = new System.Drawing.Size(50, 23);
            this.btnN4.TabIndex = 23;
            this.btnN4.Text = "N. 4";
            this.btnN4.UseVisualStyleBackColor = true;
            this.btnN4.Visible = false;
            this.btnN4.Click += new System.EventHandler(this.btnN4_Click);
            // 
            // btnN5
            // 
            this.btnN5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnN5.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnN5.Location = new System.Drawing.Point(246, 65);
            this.btnN5.Name = "btnN5";
            this.btnN5.Size = new System.Drawing.Size(50, 23);
            this.btnN5.TabIndex = 24;
            this.btnN5.Text = "N. 5";
            this.btnN5.UseVisualStyleBackColor = true;
            this.btnN5.Visible = false;
            this.btnN5.Click += new System.EventHandler(this.btnN5_Click);
            // 
            // btnE2
            // 
            this.btnE2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnE2.Location = new System.Drawing.Point(78, 179);
            this.btnE2.Name = "btnE2";
            this.btnE2.Size = new System.Drawing.Size(50, 23);
            this.btnE2.TabIndex = 28;
            this.btnE2.Text = "E. 2";
            this.btnE2.UseVisualStyleBackColor = true;
            this.btnE2.Visible = false;
            this.btnE2.Click += new System.EventHandler(this.btnE2_Click);
            // 
            // btnE1
            // 
            this.btnE1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnE1.Location = new System.Drawing.Point(18, 179);
            this.btnE1.Name = "btnE1";
            this.btnE1.Size = new System.Drawing.Size(50, 23);
            this.btnE1.TabIndex = 27;
            this.btnE1.Text = "E. 1";
            this.btnE1.UseVisualStyleBackColor = true;
            this.btnE1.Visible = false;
            this.btnE1.Click += new System.EventHandler(this.btnE1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(85, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "00";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Location = new System.Drawing.Point(30, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 20);
            this.label4.TabIndex = 25;
            this.label4.Text = "00";
            this.label4.Visible = false;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(457, 168);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(86, 23);
            this.btnVerificar.TabIndex = 29;
            this.btnVerificar.Text = "Verificar ";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Visible = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(-4, -1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(10, 11);
            this.button1.TabIndex = 30;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmResultado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(555, 242);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.btnE2);
            this.Controls.Add(this.btnE1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnN5);
            this.Controls.Add(this.btnN4);
            this.Controls.Add(this.btnN3);
            this.Controls.Add(this.btnN2);
            this.Controls.Add(this.btnN1);
            this.Controls.Add(this.btnOrdenar);
            this.Controls.Add(this.lblE2);
            this.Controls.Add(this.lblE1);
            this.Controls.Add(this.lblN5);
            this.Controls.Add(this.lblN4);
            this.Controls.Add(this.lblN3);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN1);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblEstrelas);
            this.Controls.Add(this.lblNumeros);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmResultado";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resultado";
            this.Activated += new System.EventHandler(this.frmResultado_Activated);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEstrelas;
        private System.Windows.Forms.Label lblNumeros;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnVoltar;
        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.Label lblN3;
        private System.Windows.Forms.Label lblN4;
        private System.Windows.Forms.Label lblN5;
        private System.Windows.Forms.Label lblE2;
        private System.Windows.Forms.Label lblE1;
        private System.Windows.Forms.Button btnOrdenar;
        private System.Windows.Forms.Button btnN1;
        private System.Windows.Forms.Button btnN2;
        private System.Windows.Forms.Button btnN3;
        private System.Windows.Forms.Button btnN4;
        private System.Windows.Forms.Button btnN5;
        private System.Windows.Forms.Button btnE2;
        private System.Windows.Forms.Button btnE1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Button button1;
    }
}