﻿namespace Projeto_EuroMilhoes
{
    partial class frmAposta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblN1 = new System.Windows.Forms.Label();
            this.lblN2 = new System.Windows.Forms.Label();
            this.lblN3 = new System.Windows.Forms.Label();
            this.lblN4 = new System.Windows.Forms.Label();
            this.lblN5 = new System.Windows.Forms.Label();
            this.cbN1 = new System.Windows.Forms.ComboBox();
            this.cbN2 = new System.Windows.Forms.ComboBox();
            this.cbN3 = new System.Windows.Forms.ComboBox();
            this.cbN4 = new System.Windows.Forms.ComboBox();
            this.cbN5 = new System.Windows.Forms.ComboBox();
            this.cbE2 = new System.Windows.Forms.ComboBox();
            this.cbE1 = new System.Windows.Forms.ComboBox();
            this.lblE2 = new System.Windows.Forms.Label();
            this.lblE1 = new System.Windows.Forms.Label();
            this.btnAplicar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Selecione os Números da Sorte";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(12, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(213, 28);
            this.label2.TabIndex = 2;
            this.label2.Text = "Selecione as Estrelas";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.Location = new System.Drawing.Point(92, 91);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(19, 13);
            this.lblN1.TabIndex = 3;
            this.lblN1.Text = "01";
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.Location = new System.Drawing.Point(179, 91);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(19, 13);
            this.lblN2.TabIndex = 4;
            this.lblN2.Text = "01";
            // 
            // lblN3
            // 
            this.lblN3.AutoSize = true;
            this.lblN3.Location = new System.Drawing.Point(269, 91);
            this.lblN3.Name = "lblN3";
            this.lblN3.Size = new System.Drawing.Size(19, 13);
            this.lblN3.TabIndex = 5;
            this.lblN3.Text = "01";
            // 
            // lblN4
            // 
            this.lblN4.AutoSize = true;
            this.lblN4.Location = new System.Drawing.Point(357, 91);
            this.lblN4.Name = "lblN4";
            this.lblN4.Size = new System.Drawing.Size(19, 13);
            this.lblN4.TabIndex = 6;
            this.lblN4.Text = "01";
            // 
            // lblN5
            // 
            this.lblN5.AutoSize = true;
            this.lblN5.Location = new System.Drawing.Point(439, 91);
            this.lblN5.Name = "lblN5";
            this.lblN5.Size = new System.Drawing.Size(19, 13);
            this.lblN5.TabIndex = 7;
            this.lblN5.Text = "01";
            // 
            // cbN1
            // 
            this.cbN1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbN1.FormattingEnabled = true;
            this.cbN1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbN1.Location = new System.Drawing.Point(83, 53);
            this.cbN1.Name = "cbN1";
            this.cbN1.Size = new System.Drawing.Size(38, 21);
            this.cbN1.TabIndex = 10;
            this.cbN1.SelectedIndexChanged += new System.EventHandler(this.cbN1_SelectedIndexChanged);
            // 
            // cbN2
            // 
            this.cbN2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbN2.FormattingEnabled = true;
            this.cbN2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbN2.Location = new System.Drawing.Point(169, 53);
            this.cbN2.Name = "cbN2";
            this.cbN2.Size = new System.Drawing.Size(38, 21);
            this.cbN2.TabIndex = 11;
            this.cbN2.SelectedIndexChanged += new System.EventHandler(this.cbN2_SelectedIndexChanged);
            // 
            // cbN3
            // 
            this.cbN3.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbN3.FormattingEnabled = true;
            this.cbN3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbN3.Location = new System.Drawing.Point(259, 53);
            this.cbN3.Name = "cbN3";
            this.cbN3.Size = new System.Drawing.Size(38, 21);
            this.cbN3.TabIndex = 12;
            this.cbN3.SelectedIndexChanged += new System.EventHandler(this.cbN3_SelectedIndexChanged);
            // 
            // cbN4
            // 
            this.cbN4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbN4.FormattingEnabled = true;
            this.cbN4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbN4.Location = new System.Drawing.Point(347, 53);
            this.cbN4.Name = "cbN4";
            this.cbN4.Size = new System.Drawing.Size(38, 21);
            this.cbN4.TabIndex = 13;
            this.cbN4.SelectedIndexChanged += new System.EventHandler(this.cbN4_SelectedIndexChanged);
            // 
            // cbN5
            // 
            this.cbN5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbN5.FormattingEnabled = true;
            this.cbN5.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50"});
            this.cbN5.Location = new System.Drawing.Point(430, 53);
            this.cbN5.Name = "cbN5";
            this.cbN5.Size = new System.Drawing.Size(38, 21);
            this.cbN5.TabIndex = 14;
            this.cbN5.SelectedIndexChanged += new System.EventHandler(this.cbN5_SelectedIndexChanged);
            // 
            // cbE2
            // 
            this.cbE2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbE2.FormattingEnabled = true;
            this.cbE2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cbE2.Location = new System.Drawing.Point(169, 170);
            this.cbE2.Name = "cbE2";
            this.cbE2.Size = new System.Drawing.Size(38, 21);
            this.cbE2.TabIndex = 18;
            this.cbE2.SelectedIndexChanged += new System.EventHandler(this.cbE2_SelectedIndexChanged);
            // 
            // cbE1
            // 
            this.cbE1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.cbE1.FormattingEnabled = true;
            this.cbE1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cbE1.Location = new System.Drawing.Point(83, 170);
            this.cbE1.Name = "cbE1";
            this.cbE1.Size = new System.Drawing.Size(38, 21);
            this.cbE1.TabIndex = 17;
            this.cbE1.SelectedIndexChanged += new System.EventHandler(this.cbE1_SelectedIndexChanged);
            // 
            // lblE2
            // 
            this.lblE2.AutoSize = true;
            this.lblE2.Location = new System.Drawing.Point(179, 208);
            this.lblE2.Name = "lblE2";
            this.lblE2.Size = new System.Drawing.Size(19, 13);
            this.lblE2.TabIndex = 16;
            this.lblE2.Text = "01";
            // 
            // lblE1
            // 
            this.lblE1.AutoSize = true;
            this.lblE1.Location = new System.Drawing.Point(92, 208);
            this.lblE1.Name = "lblE1";
            this.lblE1.Size = new System.Drawing.Size(19, 13);
            this.lblE1.TabIndex = 15;
            this.lblE1.Text = "01";
            // 
            // btnAplicar
            // 
            this.btnAplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAplicar.Location = new System.Drawing.Point(417, 191);
            this.btnAplicar.Name = "btnAplicar";
            this.btnAplicar.Size = new System.Drawing.Size(126, 39);
            this.btnAplicar.TabIndex = 19;
            this.btnAplicar.Text = "Aplicar Aposta";
            this.btnAplicar.UseVisualStyleBackColor = true;
            this.btnAplicar.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmAposta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(555, 242);
            this.Controls.Add(this.btnAplicar);
            this.Controls.Add(this.cbE2);
            this.Controls.Add(this.cbE1);
            this.Controls.Add(this.lblE2);
            this.Controls.Add(this.lblE1);
            this.Controls.Add(this.cbN5);
            this.Controls.Add(this.cbN4);
            this.Controls.Add(this.cbN3);
            this.Controls.Add(this.cbN2);
            this.Controls.Add(this.cbN1);
            this.Controls.Add(this.lblN5);
            this.Controls.Add(this.lblN4);
            this.Controls.Add(this.lblN3);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.lblN1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAposta";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aposta";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.Label lblN3;
        private System.Windows.Forms.Label lblN4;
        private System.Windows.Forms.Label lblN5;
        private System.Windows.Forms.ComboBox cbN1;
        private System.Windows.Forms.ComboBox cbN2;
        private System.Windows.Forms.ComboBox cbN3;
        private System.Windows.Forms.ComboBox cbN4;
        private System.Windows.Forms.ComboBox cbN5;
        private System.Windows.Forms.ComboBox cbE2;
        private System.Windows.Forms.ComboBox cbE1;
        private System.Windows.Forms.Label lblE2;
        private System.Windows.Forms.Label lblE1;
        private System.Windows.Forms.Button btnAplicar;
    }
}